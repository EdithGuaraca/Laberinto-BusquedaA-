from busquedaE import *
#from BusquedaNueva import *
import random

laberinto = []   # laberinto
aux = []  # busqueda profundidad
laberinto_t = []
inicio=0


# crear laberinto vacio
def generate_lab():
    for x in range(h):
        laberinto.append([])
        for y in range(w):
            laberinto[x].append([True,True,False])

# generar punto aleatoria para iniciar con el laberito
def generate_point():
    x = random.randint(0, h-1)
    y = random.randint(0, w-1)
    x = 0
    y = 0
    aux.append([[x,y],[x,y]])
    return [[x,y],[x,y]]

def busqueda(pointD):
    x = pointD[0][0]
    y = pointD[0][1]
    aux.remove(pointD)
    # recorrer en busca de opstaculos
    if laberinto[x][y][2] != True:
        aux.extend(exits(pointD))
        laberinto[x][y][2] = True
    tam = len(aux)
    if tam != 0:
        busqueda(aux[tam-1])
        
# determina si existe un punto del obstaculo
def exits(pointD):
    limites(pointD)
    res = []
    x = pointD[0][0]
    y = pointD[0][1]
    point = [x,y]

    if x+1 < h and laberinto[x+1][y][2] == False:
        res.append([[x+1,y],point])

    if x-1 >= 0 and laberinto[x-1][y][2] == False:
        res.append([[x-1,y],point])

    if y+1 < w and laberinto[x][y+1][2] == False:
        res.append([[x,y+1],point])

    if y-1 >= 0 and laberinto[x][y-1][2] == False :
        res.append([[x,y-1],point])

    random.shuffle(res)
    return res


def limites(pointD):
    x = pointD[0][0]
    y = pointD[0][1]
    cx = pointD[1][0]
    cy = pointD[1][1]
    if x > cx:
        laberinto[cx][cy][0] = False    
    elif cx > x:
        laberinto[x][y][0] = False    
    elif y > cy:
        laberinto[cx][cy][1] = False
    elif cy > y:
        laberinto[x][y][1] = False

# Print the laberinto in console
def printConsole():   
    out = []
    st = ""
    st1 = ""
    st2 = ""

    for x in range(h):
        for y in range(w):
            if x == 0:
                st = st + "xxx"           
            if laberinto[x][y][1]:
                st1 = st1 + "  x"
            else:
                st1 = st1 + "   "
            if laberinto[x][y][0]:
                st2 = st2 + "xxx"
            else:
                st2 = st2 + "x  "

        st1 = "x" +st1
        st2 = st2 + "x"

        if len(st) != 0:
            out.append(st)
        st = ""

        out.append(st1)
        st1 = ""
        out.append(st2)
        st2 = "" 
    
    for x in range(len(out)):
        laberinto_t.append(list(out[x]))
    laberinto_t[0].append("x")

    x_s = random.randint(0,len(laberinto_t[0])-1)
    x_f = random.randint(0,len(laberinto_t[0])-1)
    laberinto_t[0][x_s]="S"
    laberinto_t[len(laberinto_t)-1][x_f]="T"

    print("x_s= " , x_s)
    print("x_f= " , x_f)
  
    print(" ")
    print("x_s=15")
    if x_s>=15:
        x_s=15-1   
        print ("x_s-1 ", x_s)
        aEstrella(laberinto_t, x_s, x_f)   
    else:    
        aEstrella(laberinto_t, x_s, x_f)

    print(" ")
    print("x_s=0")
    if x_s>=0:
        
        aEstrella(laberinto_t, x_s, x_f)   
    else:  
        x_s=0+1   
        print ("x_s=0+1 ", x_s)  
        aEstrella(laberinto_t, x_s, x_f)  

    #for i in laberinto_t:
     #   print (i)
   
def init():
    generate_lab()
    busqueda(generate_point())
    printConsole()     

h = 5
w = 5
init()   

# Si desean que el laberinto se vea mejor, deben eliminar los caracteres especiales 
# de la matriz con el join
# Para implementar el A* deben trabajar con laberinto_t que es la matriz resultante

  